package work;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Class: CMSC203
 * Instructor: Professor Grigoriy Grinberg
 * Description: This is a Grade Calculator overall course grade. It reads 
 * the scores from a file, calculates the weighted average, and determines the student’s letter grade. 
 * The user also can choose whether to include +/- grades. When all data is collected 
 * the program creates a report with the student’s results.
 * Due: 09/14/2026
 * Platform/compiler: Eclipse
 * Integrity Pledge: I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source.
 * Student Name: Daniel Miranda
 */

public class GradeCalculator {

    private static final String PROGRAMMER_NAME = "Daniel Miranda";

    public static void main(String[] args) {

        System.out.println("========================================");
        System.out.println("   CMSC203 Project 1 - Grade Calculator");
        System.out.println("========================================");

        // Configuration
        String courseName = "CMSC203 Computer Science I";
        int numCategories = 3;
        String cat1Name = "Projects", cat2Name = "Quizzes", cat3Name = "Exams";
        int cat1Weight = 40, cat2Weight = 30, cat3Weight = 30;

        System.out.println("Using course configuration:");
        System.out.println("  " + cat1Name + ": " + cat1Weight + "%");
        System.out.println("  " + cat2Name + ": " + cat2Weight + "%");
        System.out.println("  " + cat3Name + ": " + cat3Weight + "%\n");

        //Reading the grades_input.txt
        System.out.println("Using input file: grades_input.txt");
        System.out.println("Using output file: grades_report.txt\n");

        String firstName = "", lastName = "";
        double cat1Avg = 0, cat2Avg = 0, cat3Avg = 0;
        boolean cat1Valid = false, cat2Valid = false, cat3Valid = false;

        File inputFile = new File("grades_input.txt");
        Scanner inSc;
        try {
            inSc = new Scanner(inputFile);
        } catch (IOException e) {
            System.out.println("Error: grades_input.txt not found. Exiting.");
            return;
        }

        try {
            firstName = inSc.next();
            lastName = inSc.next();

            System.out.println("Reading student scores...");

            for (int i = 0; i < numCategories; i++) {
                String catName = inSc.next();
                int count = inSc.nextInt();

                double sum = 0;
                int validCount = 0;
                for (int j = 0; j < count; j++) {
                    if (inSc.hasNextDouble()) {
                        sum += inSc.nextDouble();
                        validCount++;
                    } else if (inSc.hasNext()) {
                        inSc.next();
                    }
                }

                double avg = (validCount > 0) ? (sum / validCount) : 0.0;

                if (catName.equals(cat1Name)) {
                    cat1Avg = avg;
                    cat1Valid = (validCount > 0);
                } else if (catName.equals(cat2Name)) {
                    cat2Avg = avg;
                    cat2Valid = (validCount > 0);
                } else if (catName.equals(cat3Name)) {
                    cat3Avg = avg;
                    cat3Valid = (validCount > 0);
                } else {
                    System.out.println("Unknown category '" + catName + "' — skipping");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: grades_input.txt is malformed.");
        } finally {
            inSc.close();
        }

        System.out.println("Student: " + firstName + " " + lastName);
        System.out.println("Course: " + courseName);
        System.out.println("Category Results:");

        if (cat1Valid) {
            System.out.println("  " + cat1Name + " (" + cat1Weight + "%): average = " + String.format("%.2f", cat1Avg));
        }
        if (cat2Valid) {
            System.out.println("  " + cat2Name + " (" + cat2Weight + "%): average = " + String.format("%.2f", cat2Avg));
        }
        if (cat3Valid) {
            System.out.println("  " + cat3Name + " (" + cat3Weight + "%): average = " + String.format("%.2f", cat3Avg));
        }

        // ---------- 3. Weighted overall average ----------
        // Only categories that produced a valid average count toward both the
        // weighted sum and the weight denominator, so a missing/invalid
        // category doesn't silently drag the average down the remaining
        // weights are re-normalized to 100%.        
        double weightedSum = 0;
        double weightTotal = 0;
        if (cat1Valid) { weightedSum += cat1Avg * cat1Weight; weightTotal += cat1Weight; }
        if (cat2Valid) { weightedSum += cat2Avg * cat2Weight; weightTotal += cat2Weight; }
        if (cat3Valid) { weightedSum += cat3Avg * cat3Weight; weightTotal += cat3Weight; }

        double overallAverage = (weightTotal > 0) ? (weightedSum / weightTotal) : 0.0;

        // Grading
        // A 90-100, B 80-89.99, C 70-79.99, D 60-69.99, F below 60
        char baseLetter;
        if (overallAverage >= 90) {
            baseLetter = 'A';
        } else if (overallAverage >= 80) {
            baseLetter = 'B';
        } else if (overallAverage >= 70) {
            baseLetter = 'C';
        } else if (overallAverage >= 60) {
            baseLetter = 'D';
        } else {
            baseLetter = 'F';
        }

        // Where you input +/- for grading
        Scanner kb = new Scanner(System.in);
        String plusMinusChoice = "";
        boolean validChoice = false;

        do {
            System.out.print("Apply +/- grading? (Y/N): ");
            plusMinusChoice = kb.nextLine().trim();
            if (plusMinusChoice.equalsIgnoreCase("Y") || plusMinusChoice.equalsIgnoreCase("N")) {
                validChoice = true;
            } else {
                System.out.println("Invalid input. Please enter Y or N.");
            }
        } while (!validChoice);

        String finalLetter = String.valueOf(baseLetter);
        
        if (plusMinusChoice.equalsIgnoreCase("Y")) {
            double pos = overallAverage % 10;

            if (baseLetter == 'F') {
                finalLetter = "F";
            } else if (pos >= 8 && baseLetter != 'A') {
                finalLetter = baseLetter + "+";
            } else if (pos < 2) {
                finalLetter = baseLetter + "-";
            } else {
                finalLetter = String.valueOf(baseLetter);
            }
        }

        //Outputting the results to console and file
        System.out.println("Overall numeric average: " + String.format("%.2f", overallAverage));
        System.out.println("Base letter grade: " + baseLetter);
        System.out.println("Final letter grade: " + finalLetter);
        System.out.println("Programmer: " + PROGRAMMER_NAME);

        try {
            PrintWriter writer = new PrintWriter("grades_report.txt");

            writer.println("Course: " + courseName);
            writer.println("Student: " + firstName + " " + lastName);
            writer.println();
            writer.println("Category Results:");
            if (cat1Valid) {
                writer.println("  " + cat1Name + " (" + cat1Weight + "%): average = " + String.format("%.2f", cat1Avg));
            }
            if (cat2Valid) {
                writer.println("  " + cat2Name + " (" + cat2Weight + "%): average = " + String.format("%.2f", cat2Avg));
            }
            if (cat3Valid) {
                writer.println("  " + cat3Name + " (" + cat3Weight + "%): average = " + String.format("%.2f", cat3Avg));
            }
            writer.println();
            writer.println("Overall numeric average: " + String.format("%.2f", overallAverage));
            writer.println("Base letter grade: " + baseLetter);
            writer.println("Final letter grade: " + finalLetter);
            writer.println("Programmer: " + PROGRAMMER_NAME);

            writer.close();
            System.out.println("Summary written to grades_report.txt");
        } catch (IOException e) {
            System.out.println("Error: could not write grades_report.txt");
        }

        System.out.println("Program complete. Goodbye!");

        kb.close();
    }
}