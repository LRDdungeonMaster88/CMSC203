/**
 * Assignment Name: Lab 2 GUI JavaFX
 * File Name: FXDriver.java
 * Author: Daniel Miranda
 * Class: CMSC 203
 * Professor: Professor Grigoriy Grinberg
 * Description: Starting point of the JavaFX program. It creates the main
 * panel, puts it in a scene, and shows the window.
 */

import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FXDriver extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws IOException {
		// Task 1: create the main panel and put it in a scene
		FXMainPane root = new FXMainPane();
		stage.setScene(new Scene(root, 450, 200));

		stage.setTitle("Hello World GUI");
		stage.show();
	}
}
