/**
 * Assignment Name: Lab 2 GUI JavaFX
 * File Name: FXMainPane.java
 * Author: Daniel Miranda
 * Class: CMSC 203
 * Professor: Professor Grigoriy Grinberg
 * Description: Builds the GUI. One row shows a label and a text field, and
 * another row holds five buttons. The buttons show greetings from the
 * DataManager, clear the text field, or exit the program.
 */

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class FXMainPane extends VBox {

	// Task 2: components
	private Button helloButton, howdyButton, chineseButton, clearButton, exitButton;
	private Label feedbackLabel;
	private TextField feedbackField;
	private HBox feedbackRow, buttonRow;

	// Task 4: the data manager
	private DataManager dataManager;

	FXMainPane() {
		// Task 2: create the components
		helloButton = new Button("Hello");
		howdyButton = new Button("Howdy");
		chineseButton = new Button("Chinese");
		clearButton = new Button("Clear");
		exitButton = new Button("Exit");

		feedbackLabel = new Label("Feedback:");
		feedbackField = new TextField();

		feedbackRow = new HBox();
		buttonRow = new HBox();

		// Task 4: create the data manager
		dataManager = new DataManager();

		// Task 4: all buttons share one handler
		ButtonHandler handler = new ButtonHandler();
		helloButton.setOnAction(handler);
		howdyButton.setOnAction(handler);
		chineseButton.setOnAction(handler);
		clearButton.setOnAction(handler);
		exitButton.setOnAction(handler);

		// Task 4: spacing and centering
		Insets spacing = new Insets(10);
		HBox.setMargin(feedbackLabel, spacing);
		HBox.setMargin(feedbackField, spacing);
		HBox.setMargin(helloButton, spacing);
		HBox.setMargin(howdyButton, spacing);
		HBox.setMargin(chineseButton, spacing);
		HBox.setMargin(clearButton, spacing);
		HBox.setMargin(exitButton, spacing);

		feedbackRow.setAlignment(Pos.CENTER);
		buttonRow.setAlignment(Pos.CENTER);

		// Task 3: add components to their rows, then the rows to this VBox
		feedbackRow.getChildren().addAll(feedbackLabel, feedbackField);
		buttonRow.getChildren().addAll(helloButton, howdyButton, chineseButton, clearButton, exitButton);
		this.getChildren().addAll(feedbackRow, buttonRow);
	}

	// Task 4: handles every button click
	private class ButtonHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Object clicked = event.getTarget();

			if (clicked == helloButton) {
				feedbackField.setText(dataManager.getHello());
			} else if (clicked == howdyButton) {
				feedbackField.setText(dataManager.getHowdy());
			} else if (clicked == chineseButton) {
				feedbackField.setText(dataManager.getChinese());
			} else if (clicked == clearButton) {
				feedbackField.setText("");
			} else if (clicked == exitButton) {
				Platform.exit();
				System.exit(0);
			}
		}
	}
}
