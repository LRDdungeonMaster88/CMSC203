/**
 * Class: CMSC 203
 * Assignment: Assignment 2 - Patient Application
 * File: Patient.java
 * Description: Stores a patient's name, address, phone number and emergency
 *              contact. Provides constructors, accessors, mutators, helper
 *              methods that build formatted strings, and phone validation.
 * Due Date: __/__/____
 * Platform/Compiler: Eclipse IDE, Java (JDK)
 * Pledge: I pledge that I have completed the programming assignment
 *         independently. I have not copied the code from a student or any
 *         source. I have not given my code to any student.
 * Student: Daniel Miranda
 */
public class Patient {

	private String firstName;
	private String middleName;
	private String lastName;
	private String street;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String emergencyContactName;
	private String emergencyContactPhone;

	/**
	 * No-arg constructor. Every field starts as an empty string so the
	 * build methods never print "null".
	 */
	public Patient() {
		this("", "", "");
	}

	/**
	 * Creates a patient with only a name. The address, phone and emergency
	 * contact fields start as empty strings.
	 */
	public Patient(String first, String middle, String last) {
		this(first, middle, last, "", "", "", "", "", "", "");
	}

	/**
	 * Creates a patient and sets every attribute.
	 */
	public Patient(String first, String middle, String last, String street, String city,
			String state, String zip, String phone, String emgName, String emgPhone) {
		this.firstName = first;
		this.middleName = middle;
		this.lastName = last;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.phone = phone;
		this.emergencyContactName = emgName;
		this.emergencyContactPhone = emgPhone;
	}

	// ----- Accessors and mutators -----

	/** Returns the first name. */
	public String getFirstName() { return firstName; }
	/** Sets the first name. */
	public void setFirstName(String first) { this.firstName = first; }

	/** Returns the middle name. */
	public String getMiddleName() { return middleName; }
	/** Sets the middle name. */
	public void setMiddleName(String middle) { this.middleName = middle; }

	/** Returns the last name. */
	public String getLastName() { return lastName; }
	/** Sets the last name. */
	public void setLastName(String last) { this.lastName = last; }

	/** Returns the street address. */
	public String getStreet() { return street; }
	/** Sets the street address. */
	public void setStreet(String street) { this.street = street; }

	/** Returns the city. */
	public String getCity() { return city; }
	/** Sets the city. */
	public void setCity(String city) { this.city = city; }

	/** Returns the state. */
	public String getState() { return state; }
	/** Sets the state. */
	public void setState(String state) { this.state = state; }

	/** Returns the ZIP code. */
	public String getZip() { return zip; }
	/** Sets the ZIP code. */
	public void setZip(String zip) { this.zip = zip; }

	/** Returns the patient's phone number. */
	public String getPhone() { return phone; }
	/** Sets the patient's phone number. */
	public void setPhone(String phone) { this.phone = phone; }

	/** Returns the emergency contact's name. */
	public String getEmergencyContactName() { return emergencyContactName; }
	/** Sets the emergency contact's name. */
	public void setEmergencyContactName(String name) { this.emergencyContactName = name; }

	/** Returns the emergency contact's phone number. */
	public String getEmergencyContactPhone() { return emergencyContactPhone; }
	/** Sets the emergency contact's phone number. */
	public void setEmergencyContactPhone(String phone) { this.emergencyContactPhone = phone; }

	// ----- Build methods -----

	/**
	 * Returns the full name in the form "First Middle Last".
	 */
	public String buildFullName() {
		return firstName + " " + middleName + " " + lastName;
	}

	/**
	 * Returns the address in the form "Street City State ZIP".
	 */
	public String buildAddress() {
		return street + " " + city + " " + state + " " + zip;
	}

	/**
	 * Returns the emergency contact in the form "Name Phone".
	 */
	public String buildEmergencyContact() {
		return emergencyContactName + " " + emergencyContactPhone;
	}

	/**
	 * Returns all patient information, one item per line, using the build
	 * methods above.
	 */
	@Override
	public String toString() {
		return "Name: " + buildFullName() + "\n"
				+ "Address: " + buildAddress() + "\n"
				+ "Phone Number: " + phone + "\n"
				+ "Emergency Contact: " + buildEmergencyContact();
	}

	// ----- Additional methods -----

	/**
	 * Returns true if the patient's phone number matches ###-###-####.
	 */
	public boolean isValidPhoneNumber() {
		return matchesPhoneFormat(phone);
	}

	/**
	 * Returns true if the emergency contact's phone number matches
	 * ###-###-####.
	 */
	public boolean isValidEmergencyPhoneNumber() {
		return matchesPhoneFormat(emergencyContactPhone);
	}

	/**
	 * Returns the name in the form "Last, First Middle".
	 */
	public String getLastFirstMiddle() {
		return lastName + ", " + firstName + " " + middleName;
	}

	/**
	 * Returns true if this patient lives in the given city and state. The
	 * comparison ignores upper and lower case.
	 */
	public boolean hasSameCityState(String city, String state) {
		return this.city.equalsIgnoreCase(city) && this.state.equalsIgnoreCase(state);
	}

	/**
	 * Replaces the street, city, state and ZIP code in one call.
	 */
	public void updateAddress(String street, String city, String state, String zip) {
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}

	/**
	 * Returns a multi-line summary of the patient's and the emergency
	 * contact's names and phone numbers.
	 */
	public String getContactSummary() {
		return "Patient: " + getLastFirstMiddle() + " | Phone: " + phone + "\n"
				+ "Emergency Contact: " + emergencyContactName + " | Phone: " + emergencyContactPhone;
	}

	/**
	 * Helper that checks a phone number against the ###-###-#### pattern.
	 * A null value is treated as invalid.
	 */
	private static boolean matchesPhoneFormat(String number) {
		return number != null && number.matches("\\d{3}-\\d{3}-\\d{4}");
	}
}
