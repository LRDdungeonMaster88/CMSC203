import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * Class: CMSC 203
 * Assignment: Assignment 2 - Patient Application
 * File: PatientDriverApp.java
 * Description: Reads a patient from the keyboard, creates three procedures
 *              (one with each constructor style), and prints the patient,
 *              a procedure table, and summary statistics.
 * Due Date: __/__/____
 * Platform/Compiler: Eclipse IDE, Java (JDK)
 * Pledge: I pledge that I have completed the programming assignment
 *         independently. I have not copied the code from a student or any
 *         source. I have not given my code to any student.
 * Student: Daniel Miranda
 */
public class PatientDriverApp {

	/**
	 * Prompts for each patient field, reads it with nextLine(), and returns
	 * a Patient built with the all-attributes constructor.
	 */
	public static Patient inputPatient(Scanner input) {
		System.out.print("Enter first name: ");
		String first = input.nextLine();
		System.out.print("Enter middle name: ");
		String middle = input.nextLine();
		System.out.print("Enter last name: ");
		String last = input.nextLine();
		System.out.print("Enter street address: ");
		String street = input.nextLine();
		System.out.print("Enter city: ");
		String city = input.nextLine();
		System.out.print("Enter state: ");
		String state = input.nextLine();
		System.out.print("Enter zip: ");
		String zip = input.nextLine();
		System.out.print("Enter phone number (###-###-####): ");
		String phone = input.nextLine();
		System.out.print("Enter emergency contact name: ");
		String emgName = input.nextLine();
		System.out.print("Enter emergency contact phone (###-###-####): ");
		String emgPhone = input.nextLine();

		return new Patient(first, middle, last, street, city, state, zip, phone, emgName, emgPhone);
	}

	/**
	 * Builds the first procedure with the no-arg constructor, then uses the
	 * setters to fill in every attribute.
	 */
	public static Procedure createProcedure1() {
		Procedure p = new Procedure();
		p.setProcedureName("Physical Exam");
		p.setDate("07/20/2026");
		p.setPractitionerName("Dr. Irvine");
		p.setCharges(250.00);
		return p;
	}

	/**
	 * Builds the second procedure with the name-and-date constructor, then
	 * uses the setters for the practitioner and the charge.
	 */
	public static Procedure createProcedure2() {
		Procedure p = new Procedure("X-ray", "07/20/2026");
		p.setPractitionerName("Dr. Jamison");
		p.setCharges(550.43);
		return p;
	}

	/**
	 * Builds the third procedure with the all-attributes constructor.
	 */
	public static Procedure createProcedure3() {
		return new Procedure("Blood Test", "07/20/2026", "Dr. Smith", 1400.75);
	}

	/**
	 * Prints the patient information followed by whether each phone number
	 * has a valid format.
	 */
	public static void displayPatient(Patient patient) {
		System.out.println("\nPatient Information");
		System.out.println("-------------------");
		System.out.println(patient);
		System.out.println("Phone Valid: " + patient.isValidPhoneNumber());
		System.out.println("Emergency Phone Valid: " + patient.isValidEmergencyPhoneNumber());
	}

	/**
	 * Prints one procedure with its toString() method.
	 */
	public static void displayProcedure(Procedure procedure) {
		System.out.println(procedure);
	}

	/**
	 * Prints the three procedures in aligned columns: name, date,
	 * practitioner, charge and category.
	 */
	public static void displayProcedureTable(Procedure p1, Procedure p2, Procedure p3) {
		String format = "%-20s%-13s%-20s%-16s%s%n";
		System.out.println();
		System.out.printf(format, "Procedure", "Date", "Practitioner", "Charge", "Category");
		System.out.println("------------------------------------------------------------------------");
		for (Procedure p : new Procedure[] { p1, p2, p3 }) {
			System.out.printf(format, p.getProcedureName(), p.getDate(), p.getPractitionerName(),
					p.getFormattedCharge(), p.getChargeCategory());
		}
	}

	/**
	 * Returns the sum of the three charges.
	 */
	public static double calculateTotalCharges(Procedure p1, Procedure p2, Procedure p3) {
		return p1.getCharges() + p2.getCharges() + p3.getCharges();
	}

	/**
	 * Returns the average of the three charges.
	 */
	public static double calculateAverageCharge(Procedure p1, Procedure p2, Procedure p3) {
		return calculateTotalCharges(p1, p2, p3) / 3.0;
	}

	/**
	 * Returns whichever procedure has the largest charge. If two are tied,
	 * the earlier one is returned.
	 */
	public static Procedure findHighestChargeProcedure(Procedure p1, Procedure p2, Procedure p3) {
		Procedure highest = p1;
		if (p2.getCharges() > highest.getCharges()) {
			highest = p2;
		}
		if (p3.getCharges() > highest.getCharges()) {
			highest = p3;
		}
		return highest;
	}

	/**
	 * Returns how many of the three procedures are expensive ($1,000 or
	 * more).
	 */
	public static int countExpensiveProcedures(Procedure p1, Procedure p2, Procedure p3) {
		int count = 0;
		if (p1.isExpensiveProcedure()) count++;
		if (p2.isExpensiveProcedure()) count++;
		if (p3.isExpensiveProcedure()) count++;
		return count;
	}

	/**
	 * Prints the total, the average, the highest-charge procedure and the
	 * number of expensive procedures.
	 */
	public static void displaySummary(Procedure p1, Procedure p2, Procedure p3) {
		double total = calculateTotalCharges(p1, p2, p3);
		double average = calculateAverageCharge(p1, p2, p3);
		Procedure highest = findHighestChargeProcedure(p1, p2, p3);

		System.out.println();
		System.out.printf("Total Charges: $%,.2f%n", total);
		System.out.printf("Average Charge: $%,.2f%n", average);
		System.out.println("Highest Charge Procedure: " + highest.getProcedureName());
		System.out.println("Number of Expensive Procedures: " + countExpensiveProcedures(p1, p2, p3));
	}

	/**
	 * Runs the program: reads the patient, creates the procedures, prints
	 * everything, and ends with the developer line and today's date.
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		Patient patient = inputPatient(input);
		Procedure p1 = createProcedure1();
		Procedure p2 = createProcedure2();
		Procedure p3 = createProcedure3();

		displayPatient(patient);
		displayProcedureTable(p1, p2, p3);
		displaySummary(p1, p2, p3);

		String today = LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yy"));
		System.out.println("\nThe program was developed by a Student: "
				+ patient.getFirstName() + " " + patient.getLastName() + " " + today);

		input.close();
	}
}
