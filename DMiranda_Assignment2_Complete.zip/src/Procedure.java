/**
 * Class: CMSC 203
 * Assignment: Assignment 2 - Patient Application
 * File: Procedure.java
 * Description: Stores a medical procedure's name, date, practitioner and
 *              charge. Provides constructors, accessors, mutators, and
 *              helper methods for discounts, charge categories and
 *              formatted output.
 * Due Date: __/__/____
 * Platform/Compiler: Eclipse IDE, Java (JDK)
 * Pledge: I pledge that I have completed the programming assignment
 *         independently. I have not copied the code from a student or any
 *         source. I have not given my code to any student.
 * Student: Daniel Miranda
 */
public class Procedure {

	private String procedureName;
	private String date;
	private String practitionerName;
	private double charges;

	/**
	 * No-arg constructor. Text fields start empty and the charge is 0.0.
	 */
	public Procedure() {
		this("", "", "", 0.0);
	}

	/**
	 * Creates a procedure with a name and date. The practitioner is empty
	 * and the charge is 0.0 until they are set.
	 */
	public Procedure(String name, String date) {
		this(name, date, "", 0.0);
	}

	/**
	 * Creates a procedure and sets every attribute.
	 */
	public Procedure(String name, String date, String practitioner, double charges) {
		this.procedureName = name;
		this.date = date;
		this.practitionerName = practitioner;
		this.charges = charges;
	}

	// ----- Accessors and mutators -----

	/** Returns the procedure name. */
	public String getProcedureName() { return procedureName; }
	/** Sets the procedure name. */
	public void setProcedureName(String name) { this.procedureName = name; }

	/** Returns the procedure date. */
	public String getDate() { return date; }
	/** Sets the procedure date. */
	public void setDate(String date) { this.date = date; }

	/** Returns the practitioner's name. */
	public String getPractitionerName() { return practitionerName; }
	/** Sets the practitioner's name. */
	public void setPractitionerName(String name) { this.practitionerName = name; }

	/** Returns the charge for the procedure. */
	public double getCharges() { return charges; }
	/** Sets the charge for the procedure. */
	public void setCharges(double charges) { this.charges = charges; }

	/**
	 * Returns all procedure information on one line.
	 */
	@Override
	public String toString() {
		return "Procedure: " + procedureName + ", Date: " + date
				+ ", Practitioner: " + practitionerName
				+ ", Charge: " + getFormattedCharge();
	}

	// ----- Additional methods -----

	/**
	 * Returns true if the charge is $1,000.00 or more.
	 */
	public boolean isExpensiveProcedure() {
		return charges >= 1000.00;
	}

	/**
	 * Lowers the charge by the given percent. Only values from 0 to 100 are
	 * accepted; any other value leaves the charge unchanged.
	 */
	public void applyDiscount(double percent) {
		if (percent >= 0 && percent <= 100) {
			charges = charges - (charges * percent / 100.0);
		}
	}

	/**
	 * Returns "Low" for charges under $500, "Medium" for charges from $500
	 * up to (but not including) $1,000, and "High" for $1,000 or more.
	 */
	public String getChargeCategory() {
		if (charges < 500.00) {
			return "Low";
		} else if (charges < 1000.00) {
			return "Medium";
		} else {
			return "High";
		}
	}

	/**
	 * Returns true if the given name matches this procedure's practitioner,
	 * ignoring upper and lower case.
	 */
	public boolean isPerformedBy(String practitionerName) {
		return this.practitionerName.equalsIgnoreCase(practitionerName);
	}

	/**
	 * Returns the charge with a dollar sign, commas and two decimals, for
	 * example $1,400.75.
	 */
	public String getFormattedCharge() {
		return String.format("$%,.2f", charges);
	}
}
